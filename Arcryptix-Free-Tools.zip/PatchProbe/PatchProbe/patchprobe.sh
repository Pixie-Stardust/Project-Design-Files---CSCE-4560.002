#!/usr/bin/env bash
echo "[+] Checking for available system updates..."
if command -v apt &> /dev/null; then
    sudo apt update && apt list --upgradable
elif command -v dnf &> /dev/null; then
    sudo dnf check-update
elif command -v pacman &> /dev/null; then
    sudo pacman -Sy && pacman -Qu
else
    echo "[-] Unsupported package manager."
fi

echo "[+] Kernel version:"
uname -r
