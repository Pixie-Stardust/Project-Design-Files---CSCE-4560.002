# PatchProbe
A simple bash tool to check for system updates and display the current Linux kernel version.

## Usage
```bash
chmod +x patchprobe.sh
./patchprobe.sh
```

## Supported Package Managers
- apt (Debian/Ubuntu)
- dnf (Fedora)
- pacman (Arch)

## License
MIT
