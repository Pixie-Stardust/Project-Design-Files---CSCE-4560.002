# ReconRaptor
A lightweight reconnaissance tool built for ethical hackers. Scans common ports and performs WHOIS lookups.

## Usage
```bash
./reconraptor.py <IP or domain>
```

## Requirements
- Python 3.x
- `python-whois` library: install with `pip install python-whois`

## License
MIT
