#!/usr/bin/env python3
import socket
import whois
import sys

def banner_grab(ip, port):
    try:
        s = socket.socket()
        s.settimeout(2)
        s.connect((ip, port))
        banner = s.recv(1024).decode().strip()
        s.close()
        return banner
    except:
        return "No banner found"

def port_scan(ip):
    print(f"[+] Scanning ports on {ip}")
    common_ports = [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 445, 3389]
    for port in common_ports:
        s = socket.socket()
        s.settimeout(1)
        result = s.connect_ex((ip, port))
        if result == 0:
            print(f"[+] Port {port} open - Banner: {banner_grab(ip, port)}")
        s.close()

def whois_lookup(domain):
    try:
        info = whois.whois(domain)
        print("[+] WHOIS info:")
        print(info)
    except Exception as e:
        print(f"[-] WHOIS lookup failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: ./reconraptor.py <IP or domain>")
        sys.exit(1)
    target = sys.argv[1]
    if target.replace('.', '').isdigit():
        port_scan(target)
    else:
        whois_lookup(target)
