# SecureShellCheck
Audits your SSH daemon configuration for insecure settings.

## Usage
```bash
chmod +x secureshellcheck.sh
./secureshellcheck.sh
```

## What It Checks
- PermitRootLogin
- PasswordAuthentication
- Protocol version

## License
MIT
