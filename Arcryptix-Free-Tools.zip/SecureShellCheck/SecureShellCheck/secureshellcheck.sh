#!/usr/bin/env bash
CONFIG="/etc/ssh/sshd_config"

echo "[+] Checking SSHD configuration..."

if [ ! -f "$CONFIG" ]; then
    echo "[-] SSH configuration not found at $CONFIG"
    exit 1
fi

echo "PermitRootLogin setting:"
grep -i '^PermitRootLogin' $CONFIG || echo "  Not set"
echo "PasswordAuthentication setting:"
grep -i '^PasswordAuthentication' $CONFIG || echo "  Not set"
echo "Protocol setting:"
grep -i '^Protocol' $CONFIG || echo "  Not set"

echo "[*] Consider setting:"
echo "  PermitRootLogin no"
echo "  PasswordAuthentication no"
echo "  Protocol 2"
