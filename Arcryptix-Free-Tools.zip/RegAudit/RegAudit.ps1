Write-Host "===[ Windows Registry Security Audit ]==="

# Disable LM hashes
$lmHash = Get-ItemProperty "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" -Name "NoLMHash" -ErrorAction SilentlyContinue
if ($lmHash.NoLMHash -ne 1) {
    Write-Host "[-] LM Hash storage enabled (should be disabled)"
} else {
    Write-Host "[+] LM Hash storage is disabled"
}

# Ensure Admin Approval Mode is enabled
$uac = Get-ItemProperty "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -ErrorAction SilentlyContinue
if ($uac.EnableLUA -ne 1) {
    Write-Host "[-] UAC not enabled (EnableLUA = 0)"
} else {
    Write-Host "[+] UAC is enabled (EnableLUA = 1)"
}

# Ensure Firewall is enabled
$firewall = Get-NetFirewallProfile
foreach ($profile in $firewall) {
    if (-not $profile.Enabled) {
        Write-Host "[-] Firewall disabled on $($profile.Name)"
    } else {
        Write-Host "[+] Firewall enabled on $($profile.Name)"
    }
}
